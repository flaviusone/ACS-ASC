# Arhitectura sistemelor de calcul - Laboratorul 1
# ex. 3

# a) cititi fisierul de configurare dat ca input programului
#   - folositi metoda read_file din task2.py
#   - dati numele fisierului in timpul rularii folosind metoda raw_input
#   - puneti acest cod in "main"
# a') importati modulul task2 astfel incat sa nu mai fie nevoie de numele lui
#     la apelul metodelor din el    
# b) dati numele fisierului ca parametru la rulare, verificati ca numarul de 
#    parametri este corect, altfel afisati un mesaj de folosire script
# c) afisati numarul de configurari care au valoarea 'false'
# d) stergeti toate configurarile care au valoarea None
# e) afisati lista de parametri de configurare (nu si valorile acestora)
# f) schimbati valoarea tuturor parametrilor care incep cu "ai_" in 'true'

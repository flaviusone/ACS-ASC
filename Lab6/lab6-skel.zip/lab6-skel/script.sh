./ppu/lab6_ppu

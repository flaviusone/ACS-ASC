# Arhitectura sistemelor de calcul - Laboratorul 1
# ex. 2 - lucrul cu fisierele

# a) cititi fisierul de configurare openttd.cfg astfel incat sa mentineti toate
# configurarile necesare sub forma unui dictionar
#  - folositi metodele din modulul io
#  - ignorati liniile goale sau cele care contin doar un sir de forma [<ceva>]
#  - acolo unde proprietatea nu are setata o valoare, folositi None
#  - afisati dictionarul

# b) completati codul anterior astfel incat:
#  - sa eliminati caracterele de tip spatiu de la inceputul si sfarsitul 
#    sirurilor (metoda strip)
#  - daca proprietatile au valori numerice, pastrati-le in dictionar ca tipuri
#    numerice
#  - daca proprietatile au ca valori o lista (separate prin ','), pastrati-le
#    ca liste

# c) faceti verificare de erori de format fisier (e.g. o linie nu e de forma
#    "ceva = altceva", linie goala sau linie incepand cu [)
#  - afisati proprietatile doar daca nu s-a intalnit o eroare
#  - folositi clauza 'else' pentru bucla de citire fisier

# d) folositi modulul pickle pentru a serializa dictionarul de la punctele anterioare
#  - salvati dictionarul intr-un alt fisier
#  - incarcati dictionarul din fisierul salvat si afisati-l

# e) modificati codul astfel incat sa aveti in vedere aparitia unor exceptii
#  - exemplu folosire try/except/finally http://docs.python.org/2/tutorial/errors.html
#  - simulati aparitia unei exceptii (e.g. fisierul nu exista), afisati  mesajul
#    exceptiei
#  - folositi clauza else pentru blocul try, afisati proprietatile doar daca nu 
#    au aparut exceptii

# f) organizati codul de mai sus in metode pentru citire fisier si pentru serializare.
#  - def read_file(filepath) - intoarce un dictionar cu configurari
#  - def store_data(filepath, data)
#  - def load_data(filepath) - intoarce un dictionar
